import { Link } from 'react-router-dom'
import {
  CalendarDaysIcon,
  EllipsisHorizontalIcon,
  EyeIcon,
  LifebuoyIcon,
  MapPinIcon,
  PencilSquareIcon,
  TrashIcon,
  UserGroupIcon,
  XMarkIcon,
} from '@heroicons/react/24/outline'
import useLongPressReveal from '../../../utils/useLongPressReveal'
import {
  getBoatLocationLabel,
  getBoatPublicLocationLabel,
} from '../../../utils/locationPrivacy'
import { formatBoatType } from '../../../utils/format/boat'
import { formatCurrency } from '../../../utils/format/number'

export default function BoatCard({ boat, onDelete, deletingId }) {
  const { revealed, toggle, hide, bind } = useLongPressReveal()
  const isDeleting = deletingId === boat.id
  const locationLabel = getBoatLocationLabel(boat, 'Location not added')
  const publicLocationLabel = getBoatPublicLocationLabel(boat, '')
  const guestsLabel = boat.guests
    ? `${boat.guests} guest${boat.guests === 1 ? '' : 's'}`
    : 'Guests not set'

  return (
    <article
      {...bind}
      className="group relative overflow-hidden rounded-[30px] border border-white/15 bg-[#071d32] text-white shadow-soft transition hover:-translate-y-0.5"
    >
      <div className="relative h-56 overflow-hidden bg-navy">
        {boat.image ? (
          <img
            src={boat.image}
            alt={boat.title}
            className="h-full w-full object-cover transition duration-300 group-hover:scale-[1.03]"
          />
        ) : (
          <div className="flex h-full items-center justify-center text-gold">
            <LifebuoyIcon className="h-12 w-12" />
          </div>
        )}

        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/35 to-transparent" />

        <div className="absolute inset-x-0 top-0 flex items-start justify-between gap-3 p-3">
          <div className="flex flex-wrap gap-2">
            <span className="rounded-full bg-gold px-3 py-1 text-[11px] font-extrabold text-navy shadow-sm ring-1 ring-gold/40">
              {formatBoatType(boat.boat_type)}
            </span>

            <span className="inline-flex items-center gap-1 rounded-full bg-white px-3 py-1 text-[11px] font-bold text-navy shadow-sm">
              <UserGroupIcon className="h-3.5 w-3.5" />
              {guestsLabel}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {revealed ? (
              <>
                <button
                  type="button"
                  onClick={(e) => {
                    e.preventDefault()
                    e.stopPropagation()
                    onDelete(boat.id, boat.title)
                  }}
                  disabled={isDeleting}
                  className="inline-flex items-center gap-1 rounded-full bg-red-600 px-3 py-2 text-xs font-semibold text-white shadow-sm transition hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-60"
                >
                  <TrashIcon className="h-4 w-4" />
                  {isDeleting ? 'Deleting...' : 'Delete'}
                </button>

                <button
                  type="button"
                  onClick={(e) => {
                    e.preventDefault()
                    e.stopPropagation()
                    hide()
                  }}
                  className="rounded-full bg-gold p-2 text-navy shadow-sm ring-1 ring-gold/40 transition hover:bg-[#d8b45d]"
                  aria-label="Hide actions"
                >
                  <XMarkIcon className="h-4 w-4" />
                </button>
              </>
            ) : (
              <button
                type="button"
                onClick={(e) => {
                  e.preventDefault()
                  e.stopPropagation()
                  toggle()
                }}
                className="rounded-full bg-gold p-2 text-navy shadow-sm ring-1 ring-gold/40 transition hover:bg-[#d8b45d]"
                aria-label="Show actions"
              >
                <EllipsisHorizontalIcon className="h-5 w-5" />
              </button>
            )}
          </div>
        </div>

        <div className="absolute inset-x-0 bottom-0 px-4 pb-4 pt-14 text-white">
          <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-gold">
            Boat listing
          </p>

          <h2 className="mt-1 truncate text-2xl font-extrabold tracking-tight">
            {boat.title}
          </h2>

          <p className="mt-2 inline-flex max-w-full items-center gap-1.5 text-sm text-white/80">
            <MapPinIcon className="h-4 w-4 shrink-0 text-gold" />
            <span className="truncate">{locationLabel}</span>
          </p>
        </div>
      </div>

      <div className="space-y-4 p-4 md:p-5">
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="rounded-[20px] border border-white/15 bg-white/10 p-4">
            <p className="text-[11px] font-extrabold uppercase tracking-wide text-gold">
              Price per day
            </p>

            <p className="mt-1 text-xl font-black tracking-tight text-white">
              {formatCurrency(boat.price_per_day)}
            </p>
          </div>

          <div className="rounded-[20px] border border-white/15 bg-white/10 p-4">
            <p className="text-[11px] font-extrabold uppercase tracking-wide text-gold">
              Capacity
            </p>

            <p className="mt-1 text-xl font-black tracking-tight text-white">
              {guestsLabel}
            </p>
          </div>
        </div>

        {publicLocationLabel && publicLocationLabel !== locationLabel ? (
          <div className="rounded-[20px] border border-gold/40 bg-gold/15 p-4">
            <p className="text-[11px] font-extrabold uppercase tracking-wide text-gold">
              Public area
            </p>

            <p className="mt-1 text-sm font-semibold text-white">
              {publicLocationLabel}
            </p>
          </div>
        ) : null}

        {revealed ? (
          <div className="rounded-2xl border border-gold/40 bg-gold/15 px-3 py-2 text-xs font-medium text-white">
            Quick actions are visible. Use delete carefully.
          </div>
        ) : null}

        <div className="grid grid-cols-2 gap-2 border-t border-white/15 pt-4">
          <Link
            to={`/boats/${boat.id}`}
            className="inline-flex items-center justify-center gap-1.5 rounded-full bg-gold px-3 py-2.5 text-sm font-extrabold text-navy shadow-sm ring-1 ring-gold/40 transition hover:-translate-y-0.5 hover:bg-[#d8b45d]"
          >
            <EyeIcon className="h-4 w-4" />
            View
          </Link>

          <Link
            to={`/my-boats/${boat.id}/edit`}
            className="inline-flex items-center justify-center gap-1.5 rounded-full border border-white/25 bg-navy px-3 py-2.5 text-sm font-semibold text-white transition hover:-translate-y-0.5 hover:bg-ocean"
          >
            <PencilSquareIcon className="h-4 w-4" />
            Edit
          </Link>

          <Link
            to="/host-bookings"
            className="inline-flex items-center justify-center gap-1.5 rounded-full border border-white/25 bg-navy px-3 py-2.5 text-sm font-semibold text-white transition hover:-translate-y-0.5 hover:bg-ocean"
          >
            <CalendarDaysIcon className="h-4 w-4" />
            Bookings
          </Link>

          <button
            type="button"
            onClick={() => onDelete(boat.id, boat.title)}
            disabled={isDeleting}
            className="inline-flex items-center justify-center gap-1.5 rounded-full border border-red-400/40 bg-red-500/10 px-3 py-2.5 text-sm font-semibold text-red-100 transition hover:-translate-y-0.5 hover:bg-red-500/20 disabled:cursor-not-allowed disabled:opacity-60"
          >
            <TrashIcon className="h-4 w-4" />
            {isDeleting ? 'Deleting...' : 'Delete'}
          </button>
        </div>
      </div>
    </article>
  )
}