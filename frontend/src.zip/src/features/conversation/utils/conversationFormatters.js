export function formatDate(value) {
  if (!value) return '—'

  try {
    return new Date(value).toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    })
  } catch {
    return value
  }
}

export function formatDateTime(value) {
  if (!value) return '—'

  try {
    return new Date(value).toLocaleString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  } catch {
    return value
  }
}

export function formatTimeOnly(value) {
  if (!value) return '—'

  try {
    return new Date(value).toLocaleTimeString('en-GB', {
      hour: '2-digit',
      minute: '2-digit',
    })
  } catch {
    return value
  }
}

export function formatRelative(value) {
  if (!value) return '—'

  const date = new Date(value)
  const now = new Date()
  const diffMs = now - date
  const diffMinutes = Math.floor(diffMs / (1000 * 60))
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60))
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24))

  if (Number.isNaN(date.getTime())) return '—'
  if (diffMinutes < 1) return 'Just now'
  if (diffMinutes < 60) return `${diffMinutes} min ago`
  if (diffHours < 24) return `${diffHours}h ago`
  if (diffDays === 1) return 'Yesterday'
  if (diffDays < 7) return `${diffDays} days ago`

  return formatDate(value)
}

export function formatMoney(value) {
  if (value === null || value === undefined || value === '') return '—'

  const number = Number(value)
  if (Number.isNaN(number)) return value

  try {
    return new Intl.NumberFormat('en-NO', {
      style: 'currency',
      currency: 'NOK',
      maximumFractionDigits: 0,
    }).format(number)
  } catch {
    return `${number} kr`
  }
}

export function getConversationTypeLabel(conversation) {
  if (conversation?.booking_id || conversation?.conversation_type === 'booking') {
    return 'Booking chat'
  }

  return 'Direct inquiry'
}

export function getConversationTypeClass(conversation) {
  if (conversation?.booking_id || conversation?.conversation_type === 'booking') {
    return 'bg-gold text-navy ring-1 ring-gold/40'
  }

  return 'bg-white/10 text-white ring-1 ring-white/15'
}

export function getBookingStatusClass(status) {
  switch (status) {
    case 'confirmed':
      return 'bg-gold text-navy ring-1 ring-gold/40'
    case 'pending':
      return 'bg-gold/15 text-gold ring-1 ring-gold/40'
    case 'cancelled':
      return 'bg-red-500/15 text-red-100 ring-1 ring-red-400/40'
    default:
      return 'bg-white/10 text-white ring-1 ring-white/15'
  }
}

export function getTripState(conversation) {
  if (!conversation?.start_date || !conversation?.end_date) return 'general'
  if (conversation.booking_status === 'cancelled') return 'cancelled'
  if (conversation.booking_status === 'pending') return 'pending'

  const today = new Date()
  today.setHours(0, 0, 0, 0)

  const start = new Date(conversation.start_date)
  const end = new Date(conversation.end_date)
  start.setHours(0, 0, 0, 0)
  end.setHours(0, 0, 0, 0)

  if (end < today) return 'completed'
  if (start <= today && end >= today) return 'active'
  return 'upcoming'
}

export function getTripStateLabel(conversation) {
  const state = getTripState(conversation)

  switch (state) {
    case 'pending':
      return 'Awaiting approval'
    case 'cancelled':
      return 'Cancelled booking'
    case 'active':
      return 'Trip in progress'
    case 'completed':
      return 'Trip completed'
    case 'upcoming':
      return 'Upcoming trip'
    default:
      return 'General conversation'
  }
}

export function getTripStateClass(conversation) {
  const state = getTripState(conversation)

  switch (state) {
    case 'pending':
      return 'bg-gold/15 text-gold ring-1 ring-gold/40'
    case 'cancelled':
      return 'bg-red-500/15 text-red-100 ring-1 ring-red-400/40'
    case 'active':
      return 'bg-gold text-navy ring-1 ring-gold/40'
    case 'completed':
      return 'bg-white/10 text-white ring-1 ring-white/15'
    case 'upcoming':
      return 'bg-white text-navy ring-1 ring-white/30'
    default:
      return 'bg-white/10 text-white ring-1 ring-white/15'
  }
}

export function dayLabel(value) {
  if (!value) return ''

  const date = new Date(value)
  const today = new Date()
  const yesterday = new Date()
  yesterday.setDate(today.getDate() - 1)

  const normalize = (d) => {
    const copy = new Date(d)
    copy.setHours(0, 0, 0, 0)
    return copy.getTime()
  }

  const current = normalize(date)

  if (current === normalize(today)) return 'Today'
  if (current === normalize(yesterday)) return 'Yesterday'

  try {
    return date.toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    })
  } catch {
    return value
  }
}

export function shouldShowDateSeparator(currentMessage, previousMessage) {
  if (!currentMessage) return false
  if (!previousMessage) return true

  const currentDate = new Date(currentMessage.created_at)
  const previousDate = new Date(previousMessage.created_at)

  return currentDate.toDateString() !== previousDate.toDateString()
}